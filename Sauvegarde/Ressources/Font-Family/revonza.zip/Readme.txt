﻿Typeface © (faldykudo). <2020>. All Rights Reserved 
kudoCreative

if you find any problem/bug on my font please just feel free to contact me 
faldy.kudo@gmail.com 
i would love to fix and help you,


for full version please just click link:
https://www.creativefabrica.com/designer/xdcreative
https://www.fontbundles.net/xdcreative


find me on instagram @faldykudo

___________________________________________________________________________

SOFTWARE REQUIREMENTS :

The fonts can be opened and used in any software that can read standard fonts - even MS Word. 
No special software is required , and a friendly little help file is included to get you started :

Opentype capable software : The alternates are accessible by turning on 
"Stylistic Alternates" and "Ligatures" buttons on in Photoshop's Character panel, 
or via any software with a glyphs panel, e.g. Adobe Illustrator, Photoshop CC, Inkscape.

_______________________________________________________________________________________


support and donation

https://paypal.me/FadilAbdillah

Thank you



Regad.